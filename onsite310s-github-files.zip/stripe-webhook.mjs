// Stripe → Telegram payment alert.
// Runs every time someone pays (Stripe calls it). Works even if the customer
// never filled the booking form (e.g. they used the link from Google or Instagram).
// Needs in Netlify env vars: TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, STRIPE_WEBHOOK_SECRET (starts with whsec_)
import crypto from 'node:crypto';

const esc = s => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

function validSignature(raw, header, secret) {
  if (!header) return false;
  const parts = Object.fromEntries(header.split(',').map(p => p.split('=')).filter(p => p.length === 2 && p[0] !== 'v1'));
  const sigs = header.split(',').filter(p => p.startsWith('v1=')).map(p => p.slice(3));
  const t = parts.t;
  if (!t || !sigs.length) return false;
  if (Math.abs(Date.now() / 1000 - Number(t)) > 600) return false; // older than 10 min = replay
  const expected = crypto.createHmac('sha256', secret).update(`${t}.${raw}`).digest('hex');
  return sigs.some(s => s.length === expected.length && crypto.timingSafeEqual(Buffer.from(s), Buffer.from(expected)));
}

export default async (req) => {
  const { TELEGRAM_BOT_TOKEN: token, TELEGRAM_CHAT_ID: chat, STRIPE_WEBHOOK_SECRET: secret } = process.env;
  if (req.method !== 'POST') return new Response('ok');
  const raw = await req.text();
  if (!secret || !validSignature(raw, req.headers.get('stripe-signature'), secret)) {
    return new Response('bad signature', { status: 400 });
  }
  let evt; try { evt = JSON.parse(raw); } catch { return new Response('bad json', { status: 400 }); }
  if (!['checkout.session.completed', 'checkout.session.async_payment_succeeded'].includes(evt.type)) {
    return new Response('ignored');
  }
  const s = evt.data.object || {};
  if (evt.type === 'checkout.session.completed' && s.payment_status === 'unpaid') return new Response('waiting');
  if (!token || !chat) return new Response('Telegram not configured');

  const c = s.customer_details || {};
  const fields = (s.custom_fields || []).map(f => ({
    label: f.label?.custom || f.key,
    value: f.text?.value ?? f.dropdown?.value ?? f.numeric?.value ?? ''
  })).filter(f => f.value);
  const pick = re => fields.find(f => re.test(f.label))?.value || '';
  const vehicle = pick(/vehicle|car\b|make|model/i);
  const where = pick(/where|location|dealer|address/i);
  const other = fields.filter(f => f.value !== vehicle && f.value !== where);

  const digits = String(c.phone || '').replace(/\D/g, '');
  const intl = digits.length === 10 ? '1' + digits : digits;
  const amt = s.amount_total != null ? `$${(s.amount_total / 100).toFixed(2)} ${String(s.currency || '').toUpperCase()}` : '';
  const maps = where ? 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(where) : '';
  const isLink = /^https?:\/\//i.test(vehicle.trim());
  const dash = s.payment_intent ? `https://dashboard.stripe.com/payments/${s.payment_intent}` : '';

  const lines = [
    `💳 <b>PAID ${esc(amt)}</b> — inspection booked`,
    '',
    c.name ? `👤 <b>${esc(c.name)}</b>` : '👤 (no name collected)',
    c.phone ? `📞 ${esc(c.phone)}` : '',
    intl ? `💬 <a href="https://wa.me/${intl}">WhatsApp them</a>` : '',
    c.email ? `✉️ ${esc(c.email)}` : '',
    '',
    vehicle ? (isLink ? `🔗 <a href="${esc(vehicle.trim())}">Open the listing</a>` : `🚘 ${esc(vehicle)}`) : '',
    where ? `📍 ${esc(where)}${maps ? ` · <a href="${esc(maps)}">Map</a>` : ''}` : '',
    ...other.map(f => `• ${esc(f.label)}: ${esc(f.value)}`),
    '',
    s.client_reference_id ? `🧾 Booking ref <code>${esc(s.client_reference_id)}</code> (matches the form alert)` : '⚠️ Paid without the website form — reach out for the car details.',
    dash ? `<a href="${dash}">Open in Stripe</a>` : ''
  ].filter((l, i, a) => l !== '' || (i > 0 && a[i - 1] !== ''));

  const r = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ chat_id: chat, text: lines.join('\n'), parse_mode: 'HTML', disable_web_page_preview: true })
  });
  return new Response(r.ok ? 'sent' : 'telegram error', { status: r.ok ? 200 : 500 });
};
